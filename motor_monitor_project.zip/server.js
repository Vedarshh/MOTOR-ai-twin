const express = require('express');
const mqtt = require('mqtt');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');

const app = express();
const port = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// --- Database Configuration ---
const db = new sqlite3.Database('./motor_data.db', (err) => {
    if (err) console.error('Database connection error:', err.message);
    else console.log('Connected to SQLite database.');
});

// Create table if not exists
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS telemetry (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        temperature REAL,
        current REAL,
        vibration REAL,
        rpm INTEGER,
        status TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
});

// --- MQTT Background Processor ---
const MQTT_BROKER = 'mqtt://broker.hivemq.com:1883';
const MQTT_TOPIC = 'motor/data';
const MQTT_USER = ''; // Set if your broker requires it
const MQTT_PASS = ''; // Set if your broker requires it

const client = mqtt.connect(MQTT_BROKER, {
    username: MQTT_USER,
    password: MQTT_PASS
});

client.on('connect', () => {
    console.log('Backend connected to MQTT Broker');
    client.subscribe(MQTT_TOPIC);
});

client.on('message', (topic, message) => {
    try {
        const data = JSON.parse(message.toString());
        
        // Basic anomaly detection or status placeholder
        const status = data.temperature > 60 || data.vibration > 0.8 ? 'Critical' : 
                       data.temperature > 45 || data.vibration > 0.4 ? 'Warning' : 'Healthy';

        const sql = `INSERT INTO telemetry (temperature, current, vibration, rpm, status) VALUES (?, ?, ?, ?, ?)`;
        db.run(sql, [data.temperature, data.current, data.vibration, data.rpm, status], (err) => {
            if (err) console.error('Database insert error:', err.message);
        });
    } catch (e) {
        console.error('Failed to process MQTT message:', e.message);
    }
});

// --- API Endpoints ---
app.get('/api/history', (req, res) => {
    const limit = req.query.limit || 50;
    const sql = `SELECT * FROM telemetry ORDER BY timestamp DESC LIMIT ?`;
    
    db.all(sql, [limit], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(rows.reverse()); // Reverse to get chronological order for charts
        }
    });
});

app.get('/api/latest', (req, res) => {
    const sql = `SELECT * FROM telemetry ORDER BY timestamp DESC LIMIT 1`;
    db.get(sql, [], (err, row) => {
        if (err) res.status(500).json({ error: err.message });
        else res.json(row);
    });
});

// Start Server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
