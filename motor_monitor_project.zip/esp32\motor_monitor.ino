#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>

// --- Network & MQTT Settings ---
const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";
const char* mqtt_broker = "broker.hivemq.com";
const int mqtt_port = 1883;
const char* mqtt_topic = "motor/data";

// --- MQTT Authentication (Optional) ---
const char* mqtt_user = ""; // Set if your broker requires it
const char* mqtt_pass = ""; // Set if your broker requires it

WiFiClient espClient;
PubSubClient client(espClient);

// --- Pin Definitions ---
const int TEMP_PIN = 34;      // Analog
const int CURRENT_PIN = 35;   // Analog
const int VIB_PIN = 32;       // Analog
const int RPM_PIN = 18;       // Digital (Interrupt)

// --- Monitoring Variables ---
volatile int pulse_count = 0;
unsigned long last_rpm_millis = 0;
float rpm = 0;
float temperature = 0;
float current = 0;
float vibration = 0;

// --- Stability Filtering ---
const float EMA_ALPHA = 0.1; // Filter strength (0.1 = smooth, 0.9 = fast)

void IRAM_ATTR countPulse() {
  pulse_count++;
}

void setup() {
  Serial.begin(115200);

  // Setup Pins
  pinMode(RPM_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(RPM_PIN), countPulse, FALLING);

  // Connect WiFi
  setup_wifi();
  client.setServer(mqtt_broker, mqtt_port);
}

void setup_wifi() {
  delay(10);
  Serial.print("Connecting to ");
  Serial.println(ssid);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected");
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    String clientId = "ESP32-Motor-" + String(random(0xffff), HEX);
    
    // Connect with user/pass placeholders
    bool connected = false;
    if (String(mqtt_user).length() > 0) {
        connected = client.connect(clientId.c_str(), mqtt_user, mqtt_pass);
    } else {
        connected = client.connect(clientId.c_str());
    }

    if (connected) {
      Serial.println("connected");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      delay(5000);
    }
  }
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  static unsigned long last_report = 0;
  if (millis() - last_report > 1000) {
    last_report = millis();
    
    // Calculate RPM
    unsigned long now = millis();
    unsigned long delta = now - last_rpm_millis;
    rpm = (pulse_count * 60.0) / (delta / 1000.0);
    pulse_count = 0;
    last_rpm_millis = now;

    // Read Sensors with Filtering
    float raw_temp = analogRead(TEMP_PIN) * (3.3 / 4095.0) * 100.0; // Scaled to 100C
    float raw_curr = (analogRead(CURRENT_PIN) * (3.3 / 4095.0)) / 0.066; // ACS712 30A approx
    float raw_vib = analogRead(VIB_PIN) / 4095.0;

    // Apply EMA Filter for stability
    temperature = (EMA_ALPHA * raw_temp) + ((1.0 - EMA_ALPHA) * temperature);
    current = (EMA_ALPHA * raw_curr) + ((1.0 - EMA_ALPHA) * current);
    vibration = (EMA_ALPHA * raw_vib) + ((1.0 - EMA_ALPHA) * vibration);

    // Send JSON via MQTT
    sendTelemetry();
  }
}

void sendTelemetry() {
  JsonDocument doc;
  doc["temperature"] = serialized(String(temperature, 1));
  doc["current"] = serialized(String(current, 2));
  doc["vibration"] = serialized(String(vibration, 3));
  doc["rpm"] = (int)rpm;

  char buffer[256];
  serializeJson(doc, buffer);
  client.publish(mqtt_topic, buffer);
  
  Serial.print("Published: ");
  Serial.println(buffer);
}
